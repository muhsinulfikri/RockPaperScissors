package com.example.rockpaperscissors.enum

class Computer: Player()