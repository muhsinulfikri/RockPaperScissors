package com.example.rockpaperscissors.enum

class User: Player()